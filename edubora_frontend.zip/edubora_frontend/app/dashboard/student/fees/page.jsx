import StudentFeesPage from "@/components/pages/student/student-fees-page"

export default function StudentFees() {
  return <StudentFeesPage />
}
