import StudentLibraryPage from "@/components/pages/student/student-library-page"

export default function StudentLibrary() {
  return <StudentLibraryPage />
}
