import StudentMessagesPage from "@/components/pages/student/student-messages-page"

export default function StudentMessages() {
  return <StudentMessagesPage />
}
