import StudentReportsPage from "@/components/pages/student/student-reports-page"

export default function StudentReports() {
  return <StudentReportsPage />
}
