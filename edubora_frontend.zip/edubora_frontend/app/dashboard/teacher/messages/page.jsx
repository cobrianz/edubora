import TeacherMessagesPage from "@/components/pages/teacher/teacher-messages-page"

export default function TeacherMessages() {
  return <TeacherMessagesPage />
}
