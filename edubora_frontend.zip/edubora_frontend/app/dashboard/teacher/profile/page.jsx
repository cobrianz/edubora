import TeacherProfilePage from "@/components/pages/teacher/teacher-profile-page"

export default function TeacherProfile() {
  return <TeacherProfilePage />
}
