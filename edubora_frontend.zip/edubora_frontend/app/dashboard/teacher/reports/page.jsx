import TeacherReportsPage from "@/components/pages/teacher/teacher-reports-page"

export default function TeacherReports() {
  return <TeacherReportsPage />
}
