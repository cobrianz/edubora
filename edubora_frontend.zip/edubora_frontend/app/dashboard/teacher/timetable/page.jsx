import TeacherTimetablePage from "@/components/pages/teacher/teacher-timetable-page"

export default function TeacherTimetable() {
  return <TeacherTimetablePage />
}
